import React from "react";
import style from "./index.module.css";
import * as BABYLON from "babylonjs";
import "@babylonjs/loaders/glTF";
import "babylonjs-loaders";
import "babylonjs-materials";
import axios from 'axios';
export default function DclContent() {
// // 调用方法并处理返回的内容
// const url = 'https://peer.decentraland.org/content/contents/bafybeid7vvyfrlgrqfzao5awnpijlpagoirvsgfbwmhm7q2gylrnuczedu';
// getContent(url)
//   .then(content => {
//     console.log('Content:', content);
//     // 在这里可以根据需要对内容进行进一步处理
//   })
//   .catch(error => {
//     // 处理错误
//   });
// async function getContent(url: string): Promise<string> {
//   try {
//     const response = await axios.get(url);
//     return response.data;
//   } catch (error) {
//     console.error('Error fetching content:', error);
//     throw error;
//   }
// }
    var modelMesh = null;
    var targetBone = null
    var attachmentId = null;
    var last_rotation = [];
    var all_last_rotation = {}

    const position_x = document.getElementById("position[x]") as HTMLInputElement;
    const position_y = document.getElementById("position[y]") as HTMLInputElement;
    const position_z = document.getElementById("position[z]") as HTMLInputElement;
    const rotation_x = document.getElementById("rotation[x]") as HTMLInputElement;
    const rotation_y = document.getElementById("rotation[y]") as HTMLInputElement;
    const rotation_z = document.getElementById("rotation[z]") as HTMLInputElement;

    const scale_x = document.getElementById("scale[x]") as HTMLInputElement;
    const scale_y = document.getElementById("scale[y]") as HTMLInputElement;
    const scale_z = document.getElementById("scale[z]") as HTMLInputElement;

    var costume = {
        "id": 79413,
        "wallet": "0x60ea96f57b3a5715a90dae1440a78f8bb339c92e",
        "attachments": [],
        "skin": null,
        "name": "Costume-2",
        "default_color": "#f3f3f3"
    }


    function num(value) {
        const t = parseFloat(value);
        return t
        // return t.toString() === value.toString() ? t : null
    }


    function updatePosition(type, index, value) {
        if (!modelMesh) {
            console.log('modelMesh is Null');
            return
        }
        if (type === 'position') {
            switch (index) {
                case 0:
                    modelMesh.position.x = num(value)
                    break
                case 1:
                    modelMesh.position.y = num(value)
                    break
                case 2:
                    modelMesh.position.z = num(value)
                    break
            }
        } else if (type === 'rotation') {
            switch (index) {
                case 0:
                    modelMesh.rotation.x = num(value)
                    break
                case 1:
                    modelMesh.rotation.y = num(value)
                    break
                case 2:
                    modelMesh.rotation.z = num(value)
                    break
            }
        } else if (type === 'scale') {
            // switch (index) {
            //     case 0:
            //         modelMesh.scaling.x = num(value)
            //         break
            //     case 1:
            //         modelMesh.scaling.y = num(value)
            //         break
            //     case 2:
            //         modelMesh.scaling.z = num(value)
            //         break
            // }

            const scale_x = document.getElementById("scale[x]") as HTMLInputElement;
            const scale_y = document.getElementById("scale[y]") as HTMLInputElement;
            const scale_z = document.getElementById("scale[z]") as HTMLInputElement;
            // modelMesh.scaling.set(num(scale_x.value), num(scale_y.value), num(scale_z.value))
            // console.log(modelMesh.scaling.x);
            // return
            modelMesh.scaling.x = num(scale_x.value)
            modelMesh.scaling.y = num(scale_y.value)
            modelMesh.scaling.z = num(scale_z.value)

            modelMesh.rotationQuaternion = null;

            modelMesh.rotation.x = parseFloat(rotation_x.value);
            modelMesh.rotation.y = parseFloat(rotation_y.value);
            modelMesh.rotation.z = parseFloat(rotation_z.value);
            last_rotation[0] = modelMesh.rotation.x
            last_rotation[1] = modelMesh.rotation.y
            last_rotation[2] = modelMesh.rotation.z
        }
        updateAttachment()
    }

    function updateAttachment() {
        console.log(modelMesh,'--------------');
        
        if (!modelMesh) {
            console.log('no modelMesh');
            return
        }
        if (costume.attachments)
            costume.attachments.forEach((t => {
                // console.log(t.uuid);
                // console.log(attachmentId);
                if (t.uuid == attachmentId) {
                    t.position = [modelMesh.position.x.toFixed(2), modelMesh.position.y.toFixed(2), modelMesh.position.z.toFixed(2)]
                    t.rotation = [parseFloat(modelMesh.rotation.x).toFixed(2), parseFloat(modelMesh.rotation.y).toFixed(2), parseFloat(modelMesh.rotation.z).toFixed(2)]
                    // t.rotation = [rotation_x.value, rotation_x.value, rotation_x.value]
                    t.scaling = [parseFloat(modelMesh.scaling.x).toFixed(2), parseFloat(modelMesh.scaling.y).toFixed(2), parseFloat(modelMesh.scaling.z).toFixed(2)]
                    all_last_rotation[attachmentId] = t.rotation
                    console.log('/////////////////////');
                    
                    return true
                }
            }
            ));
    }
React.useEffect(()=>{
    const canvas = document.getElementById("renderCanvasDcl") as HTMLCanvasElement ;
    const engine = new BABYLON.Engine(canvas as HTMLCanvasElement, true);
    const createScene = function () {
        // var engine = new BABYLON.Engine(canvas, true, { antialiasing: true });

        const scene = new BABYLON.Scene(engine);

        // Set the scene's clear color
        scene.clearColor = new BABYLON.Color4(1, 1, 1, 1);

        if (onClick) {
            const lastPointerPosition = new BABYLON.Vector2();
            let isDragging = false;

            scene.onPointerObservable.add(eventData => {
                switch (eventData.type) {
                    case BABYLON.PointerEventTypes.POINTERDOWN:
                        isDragging = false;
                        lastPointerPosition.set(eventData.event.clientX, eventData.event.clientY);
                        break;
                    case BABYLON.PointerEventTypes.POINTERUP:
                        if (isDragging || eventData.event.button !== 0) return;
                        onClick(eventData.pickInfo?.hit && eventData.pickInfo.pickedMesh);
                        if (eventData.pickInfo.pickedMesh) {
                           let new_modelMesh = getRootParent(eventData.pickInfo.pickedMesh)
                            if (new_modelMesh != modelMesh) {
                                update_modelMesh(new_modelMesh)
                                focus()
                            }
                        }
                        break;
                    case BABYLON.PointerEventTypes.POINTERMOVE:
                        if (isDragging) break;
                        const distance = lastPointerPosition.subtract(new BABYLON.Vector2(eventData.event.clientX, eventData.event.clientY)).length();
                        if (distance > 8) isDragging = true;
                        break;
                }
            }, BABYLON.PointerEventTypes.POINTERDOWN + BABYLON.PointerEventTypes.POINTERUP + BABYLON.PointerEventTypes.POINTERMOVE);
        }

         // 创建 ArcRotateCamera 相机
         const camera = new BABYLON.ArcRotateCamera("Camera", -1.57, 1.4, 3.4, new BABYLON.Vector3(0, 0.9, 0), scene);
         camera.attachControl(canvas, true);
         camera.lowerRadiusLimit = 0.5;
         camera.upperRadiusLimit = 8;
         camera.wheelPrecision = 30;
         camera.panningInertia = 0;
         camera.panningSensibility = 350;
         camera.inertialRadiusOffset = 0;
         camera.minZ = 0.003;

         // 创建 Cylinder 形状的天空盒
         const skybox = BABYLON.MeshBuilder.CreateCylinder("skybox", {
             height: 64,
             diameterTop: 64,
             diameterBottom: 64,
             tessellation: 64,
             subdivisions: 64
         }, scene);
         skybox.isPickable = false;

        //  const skyMaterial = new BABYLON.GradientMaterial("skybox/horizon", scene);
        //  skyMaterial.offset = 0;
        //  skyMaterial.scale = -0.01;
        //  skyMaterial.topColor.set(0.8, 0.8, 1);
        //  skyMaterial.bottomColor.set(1, 1, 1);
        //  skyMaterial.backFaceCulling = false;
        //  skyMaterial.disableLighting = true;
        //  skyMaterial.blockDirtyMechanism = true;
        //  skybox.material = skyMaterial;

         createLightRing(scene, camera)

         // 设置高亮层
         const highlightLayer = new BABYLON.HighlightLayer("selected", scene, {
             isStroke: true
         });
         highlightLayer.innerGlow = false;
         highlightLayer.outerGlow = true;
         const glowSize = 0.4;
         highlightLayer.blurHorizontalSize = glowSize;
         highlightLayer.blurVerticalSize = glowSize;

         const light = new BABYLON.HemisphericLight("light", new BABYLON.Vector3(0, 1, 0), scene);

         // Default intensity is 1. Let's dim the light a small amount
         light.intensity = 0.7;

         const costumeMaterial = new BABYLON.StandardMaterial(`material/costume`, scene);
         costumeMaterial.diffuseColor.set(0.72, 0.81, 0.8);
         costumeMaterial.emissiveColor.set(0.1, 0.1, 0.1);
         costumeMaterial.specularPower = 500;
         costumeMaterial.blockDirtyMechanism = true;
        let material = costumeMaterial;
         // var pbrMaterial = new BABYLON.PBRMaterial("pbrMaterial", scene);
         // https://poster-phi.vercel.app/wearable/AvatarShape_B.glb
         BABYLON.SceneLoader.ImportMesh(null, `https://poster-phi.vercel.app/wearable/`, "AvatarShape_B.glb", scene, (meshes, particleSystems, skeletons) => {
             // BABYLON.SceneLoader.ImportMesh(null, `../`, "avatar.glb", scene, (meshes, particleSystems, skeletons) => {
             let costumeMesh, bodyMesh, skeletonRoot;

             // feet hands head lbody    ubody 8
             costumeMesh = meshes[0];
             const costumeId = 1;
             costumeMesh.id = `costume/${costumeId}`;
             costumeMesh.visibility = 0;
             costumeMesh.isPickable = false;
             // var mesh = meshes[3];
             // mesh.material = material;
             // mesh.isPickable = false;

             // 遍历模型的每个部分，并应用材质
             for (var i = 1; i < meshes.length; i++) {
                 var mesh = meshes[i];
                 // mesh.material = pbrMaterial;
                 // mesh.scaling.set(0.9, 0.9, 0.9)
                 // avatar_turn_around = Math.PI
                 // mesh.rotation.z = avatar_turn_around
                 mesh.isPickable = false;
             }
             // this.applySkin();
             skeletonRoot = skeletons[0];
            //  window["skeleton"] = skeletonRoot;
            skeleton = skeletonRoot;
             const bones = skeletonRoot.bones.filter((bone) => !bone.name.match(/index/i));
             const firstBone = bones[0];
             const boneTransformNode = firstBone.getTransformNode();

             if (boneTransformNode !== null) {
                 boneTransformNode.rotate(BABYLON.Axis.Y, Math.PI);
             }
             const boneMeshes = [];
             let bones_index = 0

             bones.forEach((bone) => {
                 const boneSphere = BABYLON.MeshBuilder.CreateSphere("bonesphere", {
                     diameter: 6
                 }, scene);
                 boneMeshes.push(boneSphere);
                 boneSphere.id = "bonesphere";
                let parts_i = get_avatar_bone(bones_index)
                 if (parts_i != 0) {

                     if (parts_i === 2) {
                         const newDiameter = 0.5; // 新的直径
                         boneSphere.scaling = new BABYLON.Vector3(newDiameter, newDiameter, newDiameter);
                     }
                    let addToMesh = meshes[parts_i]
                     bone.parent_mesh_name = addToMesh.name
                    //  var rotationQuaternion = new BABYLON.Quaternion.RotationAxis(new BABYLON.Vector3(1, 0, 0), Math.PI / 2);
                    var rotationQuaternion = BABYLON.Quaternion.RotationAxis(new BABYLON.Vector3(1, 0, 0), Math.PI / 2);
                     // 应用旋转变换到骨骼
                     bone.rotate(rotationQuaternion, BABYLON.Space.LOCAL);
                     boneSphere.attachToBone(bone, addToMesh);
                 }
                 boneSphere.metadata = bone.name.replace(/^.+:/, "");
                 const boneMaterial = new BABYLON.StandardMaterial("target", scene);
                 boneMaterial.emissiveColor.set(1, 1, 1);
                 boneMaterial.disableLighting = true;
                 boneMaterial.alpha = 1;
                 boneMaterial.blockDirtyMechanism = true;
                 boneSphere.material = boneMaterial;
                 boneSphere.renderingGroupId = 2;
                 boneSphere.setEnabled(false);
                 bones_index += 1
             });
         })

         return scene;
     };
     const scene = createScene();

   
     // 坐标向量
     const gizmoManager = get_GizmoManager()

     function createLightRing(scene, camera) {
         const ringTransformNode = new BABYLON.TransformNode("ring", scene);
         ringTransformNode.setParent(camera);
         ringTransformNode.position.z = -5;

         const redLight = new BABYLON.PointLight("redLight", new BABYLON.Vector3(0, 10, 0), scene);
         redLight.diffuse.set(0.1, 0.1, 0.01);
         redLight.specular.set (1, 0.7647058823529411, 0.5411764705882353)
         redLight.parent = ringTransformNode;

         const greenLight = new BABYLON.PointLight("greenLight", new BABYLON.Vector3(1, -5, 0), scene);
         greenLight.diffuse.set  (0.2784313725490196, 0.6352941176470588, 1);
         greenLight.specular.set(0, 0, 0);
         greenLight.intensity = 0.2;
         greenLight.parent = ringTransformNode;

         const blueLight = new BABYLON.PointLight("blueLight", new BABYLON.Vector3(-8.66, -1, 2), scene);
         blueLight.diffuse.set (1, 0.7058823529411765,0.4235294117647059  );
         blueLight.specular.set(0, 0, 0);
         blueLight.intensity = 0.2;
         blueLight.parent = ringTransformNode;

         const rotationAnimation = new BABYLON.Animation("lightRing", "rotation.z", 30, BABYLON.Animation.ANIMATIONTYPE_FLOAT, BABYLON.Animation.ANIMATIONLOOPMODE_CYCLE);
         const rotationKeys = [
             { frame: 0, value: 0 },
             { frame: 300, value: 2 * Math.PI }
         ];
         rotationAnimation.setKeys(rotationKeys);
         ringTransformNode.animations = [rotationAnimation];
         scene.beginAnimation(ringTransformNode, 0, 300, true);
     }

     function getRootParent(mesh) {
         if (mesh.name != 'utils/wearable_dcl') {
             return getRootParent(mesh.parent);
         } else {
             return mesh; // 如果没有父物体了，返回当前物体作为根父物体
         }
     }

     function get_avatar_bone(index) {
         // feet hands head lbody    ubody 8
         if ((index < 3 || (5 <= index && index < 7))) {
             return 4;
         } else if ((3 <= index && index < 5) || (7 <= index && index < 9)) {
             return 1;
         } else if ((9 <= index && index < 15) || (32 <= index && index < 36)) {
             return 8;
         } else if ((15 <= index && index < 32) || (36 <= index && index < 52)) {
             return 2;
         } else if (index === 53 || index === 52) {
             return 3;
         } else {
             return 0;
         }
     }

     // 模型高亮层
     function layer() {
         var e, t;
         return (t = (e = scene) === null || e === void 0 ? void 0 : e.getHighlightLayerByName("selected")) !== null && t !== void 0 ? t : null
     }

     const get_avatar = function (meshName) {
         if (!scene)
             return null;
         return scene.getMeshByName(meshName)
     }
     // get bones info
     const bonespheres = function () {
         var e, t;
         return (t = (e = scene) === null || e === void 0 ? void 0 : e.getMeshesById("bonesphere")) !== null && t !== void 0 ? t : null
     }

     // hide bones
     const hideBoneSpheres = function () {
         var e;
         (e = bonespheres()) === null || e === void 0 ? void 0 : e.forEach((e => {
             e.setEnabled(false)
         }
         ))
     }

     function onDrop() {
         hideBoneSpheres(); // 隐藏骨骼球体
         // 异步添加可穿戴物品到装饰中
         if (!targetBone) {
             console.log('no Bone');
             return
         }
         // 获取被拖放的可穿戴物品
         const droppedWearable = getDroppedWearable();
         if (!droppedWearable) {
             console.warn("no wearable"); // 没有可穿戴物品，打印警告信息
             return;
         }

         // // 判断是否能够将可穿戴物品添加到装饰中
         // if (!canAdd(droppedWearable)) {
         //     showSnackbar("Unable to add to costume", "Warning"); // 显示消息提示，无法添加到装饰中
         //     return;
         // }

         addAttachment(droppedWearable, targetBone)
             .then(() => {

             })
             .catch((error) => {
                 console.error("Error adding attachment:", error);
             });

         renderModel()

     }

     async function addAttachment(wearable, bone) {
         // if (!selectedCostume) {
         //     showSnackbar("Can't attach wearable when no costume is selected", MessageType.Warning, 5000);
         //     return;
         // }

         const defaultScale = 0.5;
         const updatedCostume = Object.assign({}, costume);
         const uniqueId = generateUUID(null,null,null);
         const attachmentInfo = {
             name: wearable.name,
             wearable_id: typeof wearable.token_id === "number" ? wearable.token_id : parseInt(wearable.token_id, 10),
             collection_address: wearable.collection_address || undefined,
             chain_id: wearable.chain_id,
             collection_id: typeof wearable.collection_id === "number" ? wearable.collection_id : parseInt(wearable.collection_id, 10),
             position: [0, 0, 0],
             rotation: [0, 0, 0],
             scaling: [defaultScale, defaultScale, defaultScale],
             bone: bone,
             category: wearable.category,
             uuid: uniqueId
         };

         if (!updatedCostume.attachments) {
             updatedCostume.attachments = [];
         }
         updatedCostume.attachments.push(attachmentInfo);
         attachmentId = uniqueId

         // const expandAttachments = true;

         // 调用api 更新Costume数据
         // await updateCostume(updatedCostume);
     }
     let skeleton = null;
     function bone(e) {

         if (!skeleton)
             return null;

         const t = skeleton.getBoneIndexByName(e);
         
         if (t == -1) {
             console.error(`Bad bone name "${e}"`);
             return null
         }
         return skeleton.bones[t]
     }

     async function renderModel() {

         // if (the_avatar) {
         // console.log(the_wearable);
         await new Promise((resolve) => {
             console.log(targetBone,99999999999999);
             
             const the_bone = bone(targetBone);
             
             if (!the_bone) {
                 console.log('no Bone');
                 return
             }
           let  the_avatar = get_avatar(the_bone.parent_mesh_name)
        //    console.log(the_avatar,222222);
           
             if (the_avatar) {

             const origin = new BABYLON.TransformNode("Node/wearable", scene);

             const shaderMaterial = new BABYLON.StandardMaterial("wearable", scene);
             shaderMaterial.emissiveColor.set(.3, .3, .3);
             shaderMaterial.diffuseColor.set(1, 1, 1);
             shaderMaterial.blockDirtyMechanism = true;

            let the_wearable = getDroppedWearable()

             modelMesh = new BABYLON.Mesh("utils/wearable_dcl", scene);
             modelMesh.material = shaderMaterial;
             modelMesh.isPickable = true;
             modelMesh.checkCollisions = false;
             modelMesh.scaling.set(100, 100, 100);
             // modelMesh.id = the_wearable.id
             modelMesh.uuid = attachmentId
             modelMesh.rotationQuaternion = null;
             modelMesh.setParent(origin);
            //  console.log(modelMesh,'model');
             origin.attachToBone(the_bone, the_avatar);
             BABYLON.SceneLoader.ImportMesh(null, 'https://peer.decentraland.org/content/contents/', the_wearable.token_id , scene, function (wearableMesh) {

                 console.log(wearableMesh);
                 console.log(the_wearable.token_id ,'///////');
                 
                 // if(modelMesh != scene.getMeshesById(the_wearable.uuid)[0]){
                 //     modelMesh = scene.getMeshesById(the_wearable.uuid)[0]
                 // }
                 // console.log(modelMesh);
                 wearableMesh[0].parent = modelMesh
                 var oldPostion = modelMesh.getBoundingInfo().boundingBox.centerWorld
                 
                 setWearablePostion(the_wearable.category, wearableMesh[0], oldPostion)
                 // wearableMesh[0].position.set(-oldPostion.x, -oldPostion.y-0.25, -oldPostion.z)
                 last_rotation = []

                 if (the_wearable?.position && the_wearable?.rotation && the_wearable?.scaling) {
                     updateAllPositionValue('load_model_json')
                 } else {
                     updateAllPositionValue(null)
                 }
                 focus()
                 
                 resolve(null)

             },null,null,'.glb'
             )

         }
         })
     }
     // }

     function setWearablePostion(category, wearableMesh, oldPostion) {
         // if (category === 'upper_body') {
         //     wearableMesh.position.set(-oldPostion.x, -oldPostion.y, -oldPostion.z)
         //     // wearableMesh.setLocalPosition(new BABYLON.Vector3(-oldPostion.x, -oldPostion.y - 0.27, -oldPostion.z))
         //     // if(category ==='hands_wear'){
         //     //     wearableMesh.scaling.set(1, 1.3, 1.3)
         //     // }
         // } else 
         
         if (category === 'lower_body') {
             wearableMesh.rotate(BABYLON.Axis.Z, Math.PI, BABYLON.Space.LOCAL);
             // wearableMesh.scaling.set(1.1, 1, 1.2)
             wearableMesh.position.set(-oldPostion.x, oldPostion.y, -oldPostion.z)
         } else if (category === 'feet') {
             wearableMesh.position.set(-oldPostion.x, -oldPostion.y - 0.11, -oldPostion.z - 0.1)
             wearableMesh.rotate(BABYLON.Axis.X, Math.PI / 2, BABYLON.Space.LOCAL);
         } else {
             wearableMesh.position.set(-oldPostion.x, -oldPostion.y, -oldPostion.z)
             // if(category ==='hands_wear'){
             //     wearableMesh.scaling.set(1, 1.3, 1.3)
             // }
         }
     }

     function getWearableBone(category) {
         // helmet eyes eyebrows mouth
         if (category === 'upper_body' || category === 'hands_wear') {
             return 'Avatar_Spine2'
         } else if (category === 'lower_body') {
             return 'Avatar_Hips'
         } else if (category === 'feet') {
             return 'Avatar_LeftToeBase'
         } else if (category === 'mask' || category === 'facial_hair' || category === 'hair' || category === 'earring' || category === 'eyewear' || category === 'eyewear' || category === 'helmet' || category === 'tiara' || category === 'top_head') {
             return 'Avatar_Head'
         } else {
             return 'Avatar_Spine'
         }
     }

     function wearableOnClick() {

         // 获取被拖放的可穿戴物品
         const droppedWearable = getDroppedWearable();
         targetBone = getWearableBone(droppedWearable.category)
         
         if (!droppedWearable) {
             console.warn("no wearable"); // 没有可穿戴物品，打印警告信息
             return;
         }

         addAttachment(droppedWearable, targetBone)
             .then(() => {

             })
             .catch((error) => {
                 console.error("Error adding attachment:", error);
             });

         renderModel()
     }

   
       // 获取 拖放的wearable
    function getDroppedWearable() {
        let droppedWearableValue = window["droppedWearable"];
        return droppedWearableValue !== null && droppedWearableValue !== undefined
          ? droppedWearableValue
          : null;
      }

     function onWheel(e) {
         e.preventDefault()
     }

     function onDragExit() {
         hideBoneSpheres()
     }

     function onDragOver(e) {
         var t;

         // 遍历所有的 bonespheres（骨骼球体）
         const all_bonespheres = bonespheres()
         if (all_bonespheres) {
             for (var i = 0; i < all_bonespheres.length; i++) {
                 var bonesphere = all_bonespheres[i];
                 // 启用每个 bonesphere
                 bonesphere.setEnabled(true);

                 if (!bonesphere.material) {
                     // 如果没有材质，则发出警告并返回
                     console.warn("no material", bonesphere);
                     continue;
                 }
                 var bonesphereMaterial = bonesphere.material;
                 // 将每个 bonesphere 的材质发光颜色设置为白色
                 bonesphereMaterial.emissiveColor.set(1, 1, 1);
             }
         }

         if (scene) {
             // 使用场景的 pick 方法，检测是否拾取到 id 为 "bonesphere" 的物体
             var pickResult = scene.pick(e.offsetX, e.offsetY, function (mesh) {
                 return mesh.id === "bonesphere";
             });

             if (pickResult && pickResult.pickedMesh && pickResult.pickedMesh.material) {
                 var pickedMaterial = pickResult.pickedMesh.material;
                 // 将拾取到的物体的材质发光颜色设置为指定颜色
                //  let emissiveMaterial = new BABYLON.StandardMaterial("emissiveMaterial", scene);
                //  emissiveMaterial.emissiveColor = new BABYLON.Color3(0.3, 0, 1);
                //  pickResult.pickedMesh.material = emissiveMaterial;
                 // 设置目标骨骼为拾取到的物体的元数据
                 targetBone = pickResult.pickedMesh.metadata;
             } else {
                 targetBone = null
             }

         }

         // 阻止浏览器默认行为
         e.preventDefault();
         if (e.dataTransfer) {
             // 设置拖拽的效果为复制
             e.dataTransfer.dropEffect = "copy";
         }
     }

     // 生成wearables列表
     function renderWearables() {
         const collectibles = [
             {
                 "id": "4f8a99d2-89c2-4c18-ab87-b35d064021a4",
                 "token_id": 'bafybeid7vvyfrlgrqfzao5awnpijlpagoirvsgfbwmhm7q2gylrnuczedu',
                 "name": "1",
                 "description": "",
                 "collection_id": 353,
                 "category": "upper_body",
                 "author": "0x38bbd375d49d6237984cbfa19719c419af9fe514",
                 "hash": "28614b00f9f807b8d71421d62d1612cab7501d20",
                 "suppressed": false,
                 "chain_id": 137,
                 "collection_address": "0x1e3D804415dCbb7ceA3478f176e123562e09b514",
                 "collection_name": "MetaCat"
             }, {
                 "id": "2222",
                 "token_id": 3,
                 "name": "face",
                 "description": "",
                 "collection_id": 353,
                 "category": "mask",
                 "author": "0x38bbd375d49d6237984cbfa19719c419af9fe514",
                 "hash": "28614b00f9f807b8d71421d62d1612cab7501d20",
                 "suppressed": false,
                 "chain_id": 137,
                 "collection_address": "0x1e3D804415dCbb7ceA3478f176e123562e09b514",
                 "collection_name": "MetaCat"
             }, {
                 "id": "333",
                 "token_id": 4,
                 "name": "all",
                 "description": "",
                 "collection_id": 353,
                 "category": "upper_body",
                 "author": "0x38bbd375d49d6237984cbfa19719c419af9fe514",
                 "hash": "28614b00f9f807b8d71421d62d1612cab7501d20",
                 "suppressed": false,
                 "chain_id": 137,
                 "collection_address": "0x1e3D804415dCbb7ceA3478f176e123562e09b514",
                 "collection_name": "MetaCat"
             }, {
                 "id": "4444",
                 "token_id": 4,
                 "name": "eyewear",
                 "description": "",
                 "collection_id": 353,
                 "category": "eyewear",
                 "author": "0x38bbd375d49d6237984cbfa19719c419af9fe514",
                 "hash": "28614b00f9f807b8d71421d62d1612cab7501d20",
                 "suppressed": false,
                 "chain_id": 137,
                 "collection_address": "0x1e3D804415dCbb7ceA3478f176e123562e09b514",
                 "collection_name": "MetaCat"
             }, {
                 "id": "4444",
                 "token_id": 5,
                 "name": "earring",
                 "description": "",
                 "collection_id": 353,
                 "category": "earring",
                 "author": "0x38bbd375d49d6237984cbfa19719c419af9fe514",
                 "hash": "28614b00f9f807b8d71421d62d1612cab7501d20",
                 "suppressed": false,
                 "chain_id": 137,
                 "collection_address": "0x1e3D804415dCbb7ceA3478f176e123562e09b514",
                 "collection_name": "MetaCat"
             }, {
                 "id": "4444",
                 "token_id": 5,
                 "name": "famale",
                 "description": "",
                 "collection_id": 353,
                 "category": "lower_body",
                 "author": "0x38bbd375d49d6237984cbfa19719c419af9fe514",
                 "hash": "28614b00f9f807b8d71421d62d1612cab7501d20",
                 "suppressed": false,
                 "chain_id": 137,
                 "collection_address": "0x1e3D804415dCbb7ceA3478f176e123562e09b514",
                 "collection_name": "MetaCat"
             }, {
                 "id": "4444",
                 "token_id": 5,
                 "name": "hand",
                 "description": "",
                 "collection_id": 353,
                 "category": "hands_wear",
                 "author": "0x38bbd375d49d6237984cbfa19719c419af9fe514",
                 "hash": "28614b00f9f807b8d71421d62d1612cab7501d20",
                 "suppressed": false,
                 "chain_id": 137,
                 "collection_address": "0x1e3D804415dCbb7ceA3478f176e123562e09b514",
                 "collection_name": "MetaCat"
             }, {
                 "id": "4444",
                 "token_id": 5,
                 "name": "facial1",
                 "description": "",
                 "collection_id": 353,
                 "category": "facial_hair",
                 "author": "0x38bbd375d49d6237984cbfa19719c419af9fe514",
                 "hash": "28614b00f9f807b8d71421d62d1612cab7501d20",
                 "suppressed": false,
                 "chain_id": 137,
                 "collection_address": "0x1e3D804415dCbb7ceA3478f176e123562e09b514",
                 "collection_name": "MetaCat"
             }, {
                 "id": "4444",
                 "token_id": 5,
                 "name": "long_hair",
                 "description": "",
                 "collection_id": 353,
                 "category": "hair",
                 "author": "0x38bbd375d49d6237984cbfa19719c419af9fe514",
                 "hash": "28614b00f9f807b8d71421d62d1612cab7501d20",
                 "suppressed": false,
                 "chain_id": 137,
                 "collection_address": "0x1e3D804415dCbb7ceA3478f176e123562e09b514",
                 "collection_name": "MetaCat"
             }, {
                 "id": "4444",
                 "token_id": 5,
                 "name": "feet",
                 "description": "",
                 "collection_id": 353,
                 "category": "feet",
                 "author": "0x38bbd375d49d6237984cbfa19719c419af9fe514",
                 "hash": "28614b00f9f807b8d71421d62d1612cab7501d20",
                 "suppressed": false,
                 "chain_id": 137,
                 "collection_address": "0x1e3D804415dCbb7ceA3478f176e123562e09b514",
                 "collection_name": "MetaCat"
             }, {
                 "id": "4444",
                 "token_id": 5,
                 "name": "hat",
                 "description": "",
                 "collection_id": 353,
                 "category": "hat",
                 "author": "0x38bbd375d49d6237984cbfa19719c419af9fe514",
                 "hash": "28614b00f9f807b8d71421d62d1612cab7501d20",
                 "suppressed": false,
                 "chain_id": 137,
                 "collection_address": "0x1e3D804415dCbb7ceA3478f176e123562e09b514",
                 "collection_name": "MetaCat"
             }, {
                 "id": "4444",
                 "token_id": 5,
                 "name": "helmet",
                 "description": "",
                 "collection_id": 353,
                 "category": "helmet",
                 "author": "0x38bbd375d49d6237984cbfa19719c419af9fe514",
                 "hash": "28614b00f9f807b8d71421d62d1612cab7501d20",
                 "suppressed": false,
                 "chain_id": 137,
                 "collection_address": "0x1e3D804415dCbb7ceA3478f176e123562e09b514",
                 "collection_name": "MetaCat"
             }, {
                 "id": "4444",
                 "token_id": 5,
                 "name": "tiara",
                 "description": "",
                 "collection_id": 353,
                 "category": "tiara",
                 "author": "0x38bbd375d49d6237984cbfa19719c419af9fe514",
                 "hash": "28614b00f9f807b8d71421d62d1612cab7501d20",
                 "suppressed": false,
                 "chain_id": 137,
                 "collection_address": "0x1e3D804415dCbb7ceA3478f176e123562e09b514",
                 "collection_name": "MetaCat"
             }, {
                 "id": "4444",
                 "token_id": 5,
                 "name": "top_head",
                 "description": "",
                 "collection_id": 353,
                 "category": "top_head",
                 "author": "0x38bbd375d49d6237984cbfa19719c419af9fe514",
                 "hash": "28614b00f9f807b8d71421d62d1612cab7501d20",
                 "suppressed": false,
                 "chain_id": 137,
                 "collection_address": "0x1e3D804415dCbb7ceA3478f176e123562e09b514",
                 "collection_name": "MetaCat"
             }
         ]
         const wearables = collectibles.map(wearable => {
             const onDragStart = event => {
                 const dataTransfer = event.dataTransfer;
                 if (dataTransfer) {
                     dataTransfer.setData("text/plain", "boop");
                 }
                 event.stopImmediatePropagation();
                 if (event.target instanceof HTMLElement) {
                     event.target.className = "dragging-wearable";
                 }
                 (window as any).droppedWearable = wearable;
             };

             const onClickWearable = event => {
                 // const dataTransfer = event.dataTransfer;
                 // if (dataTransfer) {
                 //     dataTransfer.setData("text/plain", "boop");
                 // }
                 // event.stopImmediatePropagation();
                 // if (event.target instanceof HTMLElement) {
                 //     event.target.className = "click-wearable";
                 // }
                 (window as any).droppedWearable = wearable;
                 wearableOnClick()
             };

             const onDragEnd = event => {
                 if (event.target instanceof HTMLElement) {
                     event.target.className = "draggable-wearable";
                 }
             };

             let tooltip = `wearable #${wearable.id}`;
             if (wearable.name) {
                 tooltip = wearable.name;
                 if (wearable.description) {
                     tooltip += `\n\n${wearable.description}`;
                 }
             }

             const li = document.createElement("li");
             li.className = "draggable-wearable";
             li.draggable = true;
             li.title = tooltip;
             li.addEventListener("dragstart", onDragStart);
             li.addEventListener("dragend", onDragEnd);
             li.addEventListener("click", onClickWearable);

             const img = document.createElement("img");
             img.width = 94;
             img.height = 94;
             // img.src = 'https://wearables.crvox.com/910a5b27-374e-45cc-b68c-99baf909b8d4-cv-wearables-chinese-traditional-cloak-black-by-metacat.gif'
             img.alt = tooltip;

             const div = document.createElement("div");
             div.textContent = wearable.chain_id === 0 ? "(Off-chain)" : wearable.name;
             li.appendChild(img);
             li.appendChild(div);
             return li;
         });

         // const fragment = document.createDocumentFragment();
         // const h3 = document.createElement("h3");
         // h3.textContent = `Wearables Wearables Wearables`;
         const div = document.getElementById("wearable_list");
         // div.className = "column-header";
         const ul = document.createElement("ul");
         ul.className = "wearables-list";
         wearables.forEach(li => ul.appendChild(li));
         // fragment.appendChild(h3);
         // div.appendChild(div);
         div.appendChild(ul);

         // document.body.appendChild(fragment);
     }
     renderWearables()

     function get_GizmoManager() {
         const gizmoManager = new BABYLON.GizmoManager(scene, 3.5);
         gizmoManager.positionGizmoEnabled = true;
         gizmoManager.rotationGizmoEnabled = true;
         gizmoManager.scaleGizmoEnabled = false;

         gizmoManager.boundingBoxGizmoEnabled = true;
         gizmoManager.usePointerToAttachGizmos = false;
         if (!gizmoManager.gizmos.positionGizmo || !gizmoManager.gizmos.rotationGizmo)
             throw new Error("gizmos not found");
         gizmoManager.gizmos.positionGizmo.xGizmo.dragBehavior.onDragEndObservable.add(() => updateAllPositionValue(null));
         gizmoManager.gizmos.positionGizmo.yGizmo.dragBehavior.onDragEndObservable.add(() => updateAllPositionValue(null));
         gizmoManager.gizmos.positionGizmo.zGizmo.dragBehavior.onDragEndObservable.add(() => updateAllPositionValue(null));

         gizmoManager.gizmos.rotationGizmo.xGizmo.dragBehavior.onDragEndObservable.add(() => updateAllPositionValue(null));
         gizmoManager.gizmos.rotationGizmo.yGizmo.dragBehavior.onDragEndObservable.add(() => updateAllPositionValue(null));
         gizmoManager.gizmos.rotationGizmo.zGizmo.dragBehavior.onDragEndObservable.add(() => updateAllPositionValue(null));

         gizmoManager.gizmos.rotationGizmo.updateGizmoRotationToMatchAttachedMesh = false;
         gizmoManager.boundingBoxDragBehavior.disableMovement = true;

         if (gizmoManager.gizmos.boundingBoxGizmo) {

             gizmoManager.gizmos.boundingBoxGizmo.scaleRatio = .8;
             gizmoManager.gizmos.boundingBoxGizmo.scaleBoxSize = .03;
             gizmoManager.gizmos.boundingBoxGizmo.rotationSphereSize = 0;
             gizmoManager.gizmos.boundingBoxGizmo.onScaleBoxDragEndObservable.add(() => updateAllPositionValue(null))
         }

         const position = document.getElementById("gizmo-position");
         if (!position)
             throw new Error("positionGizmo not found");
         position.addEventListener("click", (() => {
             gizmoManager.positionGizmoEnabled = true;
             gizmoManager.rotationGizmoEnabled = false;
             gizmoManager.boundingBoxGizmoEnabled = false
             // last_rotation=[]
         }
         ));
         const rotation = document.getElementById("gizmo-rotation");
         if (!rotation)
             throw new Error("rotationGizmo not found");
         rotation.addEventListener("click", (() => {
             gizmoManager.positionGizmoEnabled = false;
             gizmoManager.rotationGizmoEnabled = true;
             gizmoManager.boundingBoxGizmoEnabled = false
             // last_rotation = []
         }
         ));
         const scale = document.getElementById("gizmo-scale");
         if (!scale)
             throw new Error("scaleGizmo not found");
         scale.addEventListener("click", (() => {
             // if(modelMesh){
             //     modelMesh.rotationQuaternion = null;
             // }
             if (modelMesh) {
                 last_rotation[0] = modelMesh.rotation.x
                 last_rotation[1] = modelMesh.rotation.y
                 last_rotation[2] = modelMesh.rotation.z
             }
             gizmoManager.positionGizmoEnabled = false;
             gizmoManager.rotationGizmoEnabled = false;
             gizmoManager.boundingBoxGizmoEnabled = true

         }
         ));
         gizmoManager.positionGizmoEnabled = true;
         gizmoManager.rotationGizmoEnabled = false;
         gizmoManager.boundingBoxGizmoEnabled = false;
         return gizmoManager
     }

     function focus() {
        let lay = layer()
         const col = new BABYLON.Color3(.7, .3, 1);
console.log(modelMesh,2222222222);

         if (lay && modelMesh) {
             lay.removeAllMeshes();
             // 获取根元素的所有子网格
             var childMeshes = modelMesh.getChildMeshes();

             // 遍历子网格数组
             for (var i = 0; i < childMeshes.length; i++) {
                 var childMesh = childMeshes[i];
                 lay.addMesh(childMesh, col)
                 // 在这里对每个子网格进行操作，比如设置材质、位置、旋转等
             }
         }
         if (gizmoManager && modelMesh) {

             gizmoManager.attachToMesh(modelMesh)
         }
     }

     function dispose_mesh() {
         if (modelMesh) {
             modelMesh.dispose(); // 销毁模型及其资源
             deleteAttachment()
             update_modelMesh(null)
             updateAllPositionValue(null)
         }
     }

   

     function update_modelMesh(value) {

         modelMesh = value

         if (modelMesh) {
             attachmentId = modelMesh.uuid
             last_rotation = all_last_rotation[attachmentId]
             console.log(last_rotation);
         } else {
             attachmentId = null
         }

         updateAllPositionValue('change_model_mesh')
     }

    //    // pass
    //    function updateInputPositionValue(type, dir) {
    //     if (!modelMesh) {
    //         return
    //     }
    //     if (type === 'position') {
    //         switch (dir) {
    //             case 0:
    //                 const position_x = document.getElementById("position[x]");
    //                 position_x.value = modelMesh.position.x.toFixed(2);
    //                 break
    //             case 1:
    //                 const position_y = document.getElementById("position[y]");
    //                 position_y.value = modelMesh.position.y.toFixed(2);
    //                 break
    //             case 2:
    //                 const position_z = document.getElementById("position[z]");
    //                 position_z.value = modelMesh.position.z.toFixed(2);
    //                 break
    //         }
    //     } else if (type === 'rotation') {
    //         switch (dir) {
    //             case 0:
    //                 const rotation_x = document.getElementById("rotation[x]");
    //                 rotation_x.value = modelMesh.rotation.x.toFixed(2);
    //                 break
    //             case 1:
    //                 const rotation_y = document.getElementById("rotation[y]");
    //                 rotation_y.value = modelMesh.rotation.y.toFixed(2);
    //                 break
    //             case 2:
    //                 const rotation_z = document.getElementById("rotation[z]");
    //                 rotation_z.value = modelMesh.rotation.z.toFixed(2);
    //                 break
    //         }
    //     } else if (type === 'scale') {
    //         // switch (dir) {
    //         //     case 0:
    //         //         const scale_x = document.getElementById("scale[x]");
    //         //         scale_x.value = modelMesh.scaling.x.toFixed(2);
    //         //         break
    //         //     case 1:
    //         //         const scale_y = document.getElementById("scale[y]");
    //         //         scale_y.value = modelMesh.scaling.y.toFixed(2);
    //         //         break
    //         //     case 2:
    //         //         const scale_z = document.getElementById("scale[z]");
    //         //         scale_z.value = modelMesh.scaling.z.toFixed(2);
    //         //         break
    //         // }
    //         const scale_x = document.getElementById("scale[x]");
    //         const scale_y = document.getElementById("scale[y]");
    //         const scale_z = document.getElementById("scale[z]");
    //         console.log(modelMesh.scaling.x.toFixed(2));
    //         console.log(modelMesh.scaling.y.toFixed(2));
    //         console.log(modelMesh.scaling.z.toFixed(2));
    //         scale_x.value = modelMesh.scaling.x.toFixed(2);
    //         scale_y.value = modelMesh.scaling.y.toFixed(2);
    //         scale_z.value = modelMesh.scaling.z.toFixed(2);

    //     }

    // }

    function updateAllPositionValue(type) {
console.log(modelMesh,4444444444,type);
const position_x = document.getElementById("position[x]") as HTMLInputElement;
const position_y = document.getElementById("position[y]") as HTMLInputElement;
const position_z = document.getElementById("position[z]") as HTMLInputElement;
const rotation_x = document.getElementById("rotation[x]") as HTMLInputElement;
const rotation_y = document.getElementById("rotation[y]") as HTMLInputElement;
const rotation_z = document.getElementById("rotation[z]") as HTMLInputElement;

const scale_x = document.getElementById("scale[x]") as HTMLInputElement;
const scale_y = document.getElementById("scale[y]") as HTMLInputElement;
const scale_z = document.getElementById("scale[z]") as HTMLInputElement;
        if (!modelMesh) {
            position_x.value = 0.00.toString();
            position_y.value = 0.00.toString();
            position_z.value = 0.00.toString();

            rotation_x.value = 0.00.toString();
            rotation_y.value = 0.00.toString();
            rotation_z.value = 0.00.toString();

            scale_x.value = (100).toString();
            scale_y.value = (100).toString();
            scale_z.value = (100).toString();
        } else if (type === 'change_model_mesh') {
            position_x.value = modelMesh.position.x.toFixed(2);
            position_y.value = modelMesh.position.y.toFixed(2);
            position_z.value = modelMesh.position.z.toFixed(2);

            scale_x.value = modelMesh.scaling.x.toFixed(2);
            scale_y.value = modelMesh.scaling.y.toFixed(2);
            scale_z.value = modelMesh.scaling.z.toFixed(2);
            modelMesh.rotationQuaternion = null;

            rotation_x.value = modelMesh.rotation.x = last_rotation[0]
            rotation_y.value = modelMesh.rotation.y = last_rotation[1]
            rotation_z.value = modelMesh.rotation.z = last_rotation[2]
        } else {
            // const rot = e=>Math.round(e * 1e3 * 180 / Math.PI) / 1e3;
            // const po_sc = e=>Math.round(e * 1e3) / 1e3;
            if (type === 'load_model_json') {
              let  the_wearable = getDroppedWearable()

                modelMesh.position.x = parseFloat(the_wearable.position[0]);
                modelMesh.position.y = parseFloat(the_wearable.position[1]);
                modelMesh.position.z = parseFloat(the_wearable.position[2]);

                modelMesh.rotation.x = parseFloat(the_wearable.rotation[0]);
                modelMesh.rotation.y = parseFloat(the_wearable.rotation[1]);
                modelMesh.rotation.z = parseFloat(the_wearable.rotation[2]);

                modelMesh.scaling.x = parseFloat(the_wearable.scaling[0]);
                modelMesh.scaling.y = parseFloat(the_wearable.scaling[1]);
                modelMesh.scaling.z = parseFloat(the_wearable.scaling[2]);
            }
// console.log(Number(modelMesh.position.x),5666665,modelMesh.position.x);
// position_x.value = parseFloat(modelMesh.position.x.toFixed(2)).toFixed(2);
// console.log(position_x.value,255565);
console.log(position_x);

            position_x.value = modelMesh.position.x.toFixed(2);

            position_y.value = modelMesh.position.y.toFixed(2);
            position_z.value = modelMesh.position.z.toFixed(2);
            
            console.log('-------======================');

            scale_x.value = modelMesh.scaling.x.toFixed(2);
            scale_y.value = modelMesh.scaling.y.toFixed(2);
            scale_z.value = modelMesh.scaling.z.toFixed(2);
            modelMesh.rotationQuaternion = null;

            if (last_rotation.length === 0) {
                rotation_x.value = modelMesh.rotation.x.toFixed(2);
                rotation_y.value = modelMesh.rotation.y.toFixed(2);
                rotation_z.value = modelMesh.rotation.z.toFixed(2);
            } else {
                rotation_x.value = modelMesh.rotation.x = parseFloat(last_rotation[0]).toFixed(2);
                rotation_y.value = modelMesh.rotation.y = parseFloat(last_rotation[1]).toFixed(2);
                rotation_z.value = modelMesh.rotation.z = parseFloat(last_rotation[2]).toFixed(2);
                if (!gizmoManager.boundingBoxGizmoEnabled) {
                    last_rotation = []
                }
            }

            if (!type) {
                updateAttachment()
            }
        }
    }

    function deleteAttachment() {
        if (!modelMesh) {
            console.log('no modelMesh');
            return
        }

        if (costume.attachments)
            var index = 0;
        costume.attachments.forEach((t => {
            if (t.uuid == attachmentId) {
                costume.attachments.splice(index, 1);
                return
            }
            index += 1
        }
        ));
    }

  
    function downloadCostume() {
        console.log(costume);
        var file_name;
        // const t = this.costume;
        if (!costume)
            return;
        const json_costume = JSON.stringify(costume, null, 2);
        const element_dow = document.createElement("a");
        element_dow.style.display = "hidden";
        element_dow.href = window.URL.createObjectURL(new Blob([json_costume], {
            type: "application/json"
        }));
        element_dow.download = ((file_name = costume.name) !== null && file_name !== void 0 ? file_name : costume.id) + ".json";
        element_dow.click();
        element_dow.remove()
    }

    async function onLoadCostume() {
        const response = await fetch('./load1.json');
        const data = await response.json();

        // 在这里使用从JSON文件中读取到的数据
        const attachments = data.attachments;

        for (let att of attachments) {

            (window as any).droppedWearable = att;
            targetBone = att.bone;
            attachmentId = att.uuid
            all_last_rotation[attachmentId] = att.rotation
            costume.attachments.push(att)
            await renderModel();``
        }

        onClick(null)
    }

    const onClick = e => {
        if (!e) {
            if (layer())
                layer().removeAllMeshes();
            if (gizmoManager) {
                gizmoManager.attachToMesh(null)
            }
            update_modelMesh(null)
        }
    };

    function generateUUID(e, random, r) {
        let lastNsecs = 0
        let lastTimestamp = 0;
        let lastClockSequence = null;
        let nodeIdentifier = null;

        let index = (random && r) || 0;
        const uuidArray = random || new Array(16);
        e = e || {};

        let node = e.node || nodeIdentifier;
        let clockSeq = e.clockSeq !== undefined ? e.clockSeq : lastClockSequence;

        if (node === null || clockSeq === null) {
            const random = getRandomValues();
            if (node === null) {
                node = nodeIdentifier = [random[0] | 1, random[1], random[2], random[3], random[4], random[5]];
            }
            if (clockSeq === null) {
                clockSeq = lastClockSequence = (random[6] << 8 | random[7]) & 16383;
            }
        }

        let timestamp = e.timestamp !== undefined ? e.timestamp : Date.now();
        let nsecs = e.nsecs !== undefined ? e.nsecs : lastNsecs + 1;

        const clockOffset = (timestamp - lastTimestamp + (nsecs - lastNsecs)) / 10000;

        if (clockOffset < 0 && e.clockSeq === undefined) {
            clockSeq = (clockSeq + 1) & 16383;
        }

        if ((clockOffset < 0 || timestamp > lastTimestamp) && e.nsecs === undefined) {
            nsecs = 0;
        }

        if (nsecs >= 10000) {
            throw new Error("generateUUID(): Can't create more than 10M uuids/sec");
        }

        lastTimestamp = timestamp;
        lastNsecs = nsecs;
        lastClockSequence = clockSeq;

        timestamp += 122192928e5;
        const timeLow = ((timestamp & 268435455) * 10000 + nsecs) % 4294967296;
        uuidArray[index++] = timeLow >>> 24 & 255;
        uuidArray[index++] = timeLow >>> 16 & 255;
        uuidArray[index++] = timeLow >>> 8 & 255;
        uuidArray[index++] = timeLow & 255;

        const timeMid = timestamp / 4294967296 * 10000 & 268435455;
        uuidArray[index++] = timeMid >>> 8 & 255;
        uuidArray[index++] = timeMid & 255;
        uuidArray[index++] = timeMid >>> 24 & 15 | 16;
        uuidArray[index++] = timeMid >>> 16 & 255;

        uuidArray[index++] = clockSeq >>> 8 | 128;
        uuidArray[index++] = clockSeq & 255;

        for (let i = 0; i < 6; ++i) {
            uuidArray[index + i] = node[i];
        }
        return byteArrayToHexString(uuidArray);
    }

    function getRandomValues() {
        let getRandom;
        const arr = new Uint8Array(16);
        if (!getRandom) {
            getRandom = typeof crypto !== "undefined" && crypto.getRandomValues && crypto.getRandomValues.bind(crypto);
            if (!getRandom)
                throw new Error("crypto.getRandomValues() not supported. See https://github.com/uuidjs/uuid#getrandomvalues-not-supported")
        }
        return getRandom(arr)
    }
    let hexChars = [];
    for (let i = 0; i < 256; ++i) {
        hexChars.push((i + 256).toString(16).slice(1));
    }

    function byteArrayToHexString(byteArray, startIndex = 0) {
        return (
            hexChars[byteArray[startIndex + 0]] +
            hexChars[byteArray[startIndex + 1]] +
            hexChars[byteArray[startIndex + 2]] +
            hexChars[byteArray[startIndex + 3]] +
            "-" +
            hexChars[byteArray[startIndex + 4]] +
            hexChars[byteArray[startIndex + 5]] +
            "-" +
            hexChars[byteArray[startIndex + 6]] +
            hexChars[byteArray[startIndex + 7]] +
            "-" +
            hexChars[byteArray[startIndex + 8]] +
            hexChars[byteArray[startIndex + 9]] +
            "-" +
            hexChars[byteArray[startIndex + 10]] +
            hexChars[byteArray[startIndex + 11]] +
            hexChars[byteArray[startIndex + 12]] +
            hexChars[byteArray[startIndex + 13]] +
            hexChars[byteArray[startIndex + 14]] +
            hexChars[byteArray[startIndex + 15]]
        ).toLowerCase();
    }

    // canvas增加监听事件
    canvas.addEventListener('wheel', onWheel);
    canvas.addEventListener('dragover', onDragOver);
    canvas.addEventListener('dragleave', onDragExit);
    canvas.addEventListener('drop', onDrop);
    canvas.classList.add('costumer');

    const wearableElement = document.getElementById("yourWearableElementId");

    // 获取按钮元素
    const deleteButton = document.getElementById('mesh_dispose');
    const download_json_file = document.getElementById('download');
    const up_load = document.getElementById('upload');
    // 添加点击事件处理程序
    deleteButton.addEventListener('click', dispose_mesh);
    download_json_file.addEventListener('click', downloadCostume);
    up_load.addEventListener('click', onLoadCostume);

    engine.runRenderLoop(function () {
        scene.render();
    });

    window.addEventListener("resize", function () {
        engine.resize();
    });

})

  return (
    <>
      <div
        id="gizmos"
        className="active"
        style={{ position: "relative", height: "90%", top: "5%" }}
      >
        <canvas id="renderCanvasDcl" className={style.canvas}></canvas>
        <div style={{ position: "absolute", top: "10px" }}>
          <button className={style.btn} id="gizmo-position">Position</button>
          <button className={style.btn} id="gizmo-rotation">Rotation</button>
          <button className={style.btn} id="gizmo-scale">Scale</button>
        </div>
        <div style={{ position: "absolute", right: "10px", top: "10px" }}>
          <div className="editor-field position">
            <label>Position</label>
            <div className="fields">
              <input
                id="position[x]"
                type="number"
                step="1"
                title="x"
                value='0'
                onInput={() => {
                  updatePosition("position", 0, this.value);
                }}
                onChange={() => {
                  updatePosition("position", 0, this.value);
                }}
              />
              <input
                id="position[y]"
                type="number"
                step="1"
                title="y"
                value='0'
                onInput={() => {
                  updatePosition("position", 1, this.value);
                }}
                onChange={() => {
                  updatePosition("position", 1, this.value);
                }}
              />
              <input
                id="position[z]"
                type="number"
                step="1"
                title="z"
                value='0'
                onInput={() => {
                  updatePosition("position", 2, this.value);
                }}
                onChange={() => {
                  updatePosition("position", 2, this.value);
                }}
              />
            </div>
          </div>
          <div className="editor-field rotation">
            <label>Rotation</label>
            <div className="fields">
              <input
                id="rotation[x]"
                type="number"
                step="1"
                title="x"
                value='0'
                onInput={() => {
                  updatePosition("rotation", 0, this.value);
                }}
                onChange={() => {
                  updatePosition("rotation", 0, this.value);
                }}
              />
              <input
                id="rotation[y]"
                type="number"
                step="1"
                title="y"
                value='0'
                onInput={() => {
                  updatePosition("rotation", 1, this.value);
                }}
                onChange={() => {
                  updatePosition("rotation", 1, this.value);
                }}
              />
              <input
                id="rotation[z]"
                type="number"
                step="1"
                title="z"
                value='0'
                onInput={() => {
                  updatePosition("rotation", 2, this.value);
                }}
                onChange={() => {
                  updatePosition("rotation", 2, this.value);
                }}
              />
            </div>
          </div>
          <div className="editor-field scale-all">
            <label>Scale</label>
            <div className="fields">
              <input
                id="scale[x]"
                type="number"
                step="1"
                title="all"
                value="100"
                onInput={() => {
                  updatePosition("scale", 0, this.value);
                }}
                onChange={() => {
                  updatePosition("scale", 0, this.value);
                }}
              />
              <input
                id="scale[y]"
                type="number"
                step="1"
                title="all"
                value="100"
                onInput={() => {
                  updatePosition("scale", 1, this.value);
                }}
                onChange={() => {
                  updatePosition("scale", 1, this.value);
                }}
              />
              <input
                id="scale[z]"
                type="number"
                step="1"
                title="all"
                value="100"
                onInput={() => {
                  updatePosition("scale", 2, this.value);
                }}
                onChange={() => {
                  updatePosition("scale", 2, this.value);
                }}
              />
              {/* <!-- <button class="toggle">...</button> --> */}
            </div>
          </div>
          <div>
            <button className={style.buton} id="mesh_dispose">Remove</button>
            <button className={style.buton} id="download">Download</button>
            <button className={style.buton} id="upload">Upload</button>
          </div>
          <div id="wearable_list"></div>
        </div>
      </div>
    </>
  );
}
